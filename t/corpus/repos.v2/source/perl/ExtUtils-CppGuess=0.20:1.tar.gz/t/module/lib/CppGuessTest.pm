package CppGuessTest;

our $VERSION = '0.01';

use XSLoader;

XSLoader::load 'CppGuessTest', $VERSION;

1;
